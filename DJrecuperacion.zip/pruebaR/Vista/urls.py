from django.urls import path
from rest_framework import routers
from django.conf.urls import url , include
from . import views
routers=routers.DefaultRouter()
routers.register(r'jefe', views.JefeViewSet)
routers.register(r'contrato', views.ContratoViewSet)
routers.register(r'trabajador', views.TrabajadorViewSet)

urlpatterns = [
    path('', views.index, name='index'),
    url(r'^', include(routers.urls)),
    url(r'^api-auth',include('rest_framework.urls',namespace='rest_framework'))
    



]