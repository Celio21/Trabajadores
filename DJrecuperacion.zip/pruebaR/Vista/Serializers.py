from Vista.models import Jefe , Contrato ,Trabajador
from rest_framework import serializers 
class JefeSerializers(serializers.HyperlinkedModelSerializer):
    class Meta:
        model=Jefe,
        fields={'nombre','cedula','correo'}
class ContratoSerializers(serializers.HyperlinkedModelSerializer):
    class Meta:
        model=Contrato,
        fields={'maestro','nombre','tipo','horas'}
class TrabajadorSerializers(serializers.HyperlinkedModelSerializer):
    class Meta:
        model=Trabajador,
        fields={'contrato','nombre','ciclo','edad'}

