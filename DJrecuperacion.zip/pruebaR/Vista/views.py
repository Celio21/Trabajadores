from django.http import HttpResponse
from Vista.models import Jefe,Contrato,Trabajador
from rest_framework import viewsets
from Vista.Serializers import JefeSerializers,ContratoSerializers,TrabajadorSerializers
class JefeViewSet(viewsets.ModelViewSet):
    queryset=Jefe.objects.all().order_by('nombre')
    serializer_class=JefeSerializers
class ContratoViewSet(viewsets.ModelViewSet):
    queryset=Contrato.objects.all().order_by('tipo')
    serializer_class=ContratoSerializers
class TrabajadorViewSet(viewsets.ModelViewSet):
    queryset=Trabajador.objects.all().order_by('nombre')
    serializer_class=TrabajadorSerializers
def index(request):
    return HttpResponse("No quiero reprobar señor Stark")
