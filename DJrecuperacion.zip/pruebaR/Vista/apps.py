from django.apps import AppConfig


class VistaConfig(AppConfig):
    name = 'Vista'
