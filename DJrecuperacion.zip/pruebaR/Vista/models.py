from django.db import models

# Create your models here.
class Jefe(models.Model):
    nombre=models.CharField(max_length=100)
    cedula=models.IntegerField(default=0)
    correo=models.CharField(max_length=100)
class Contrato(models.Model):
    maestro=models.ForeignKey(Jefe, on_delete=models.CASCADE)
    nombre=models.CharField(max_length=100)
    tipo=models.CharField(max_length=100)
    horas=models.IntegerField(default=0)
class Trabajador(models.Model):
    contrato=models.ForeignKey(Contrato, on_delete=models.CASCADE)
    nombre=models.CharField(max_length=100)
    ciclo=models.IntegerField(default=0)
    edad=models.IntegerField(default=0)
    
