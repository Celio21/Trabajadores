from django.contrib import admin
from.models import Jefe
from.models import Contrato
from.models import Trabajador
# Register your models here.
admin.site.register(Jefe)
admin.site.register(Contrato)
admin.site.register(Trabajador)